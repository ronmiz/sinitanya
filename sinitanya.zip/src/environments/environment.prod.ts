export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyBGJO41bfsIPjSsM67lv7D6vmPvU2ukK8M",
    authDomain: "sinitanya-9da30.firebaseapp.com",
    databaseURL: "https://sinitanya-9da30.firebaseio.com",
    projectId: "sinitanya-9da30",
    storageBucket: "sinitanya-9da30.appspot.com",
    messagingSenderId: "658064080864"   
  }
};
