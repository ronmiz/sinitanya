export const ProgramData = [
        { id: 1, name: '1 מסלול', limit: '220', price: '180'},
        { id: 2, name: '2 מסלול', limit: '450' , price: '360' },
        { id: 3, name: '3 מסלול', limit: '770' , price: '536' },
        { id: 4, name: '4 מסלול', limit: '1100', price: '770' },
        { id: 5, name: '5 מסלול', limit: '1100', price: '1100' },
        { id: 6, name: 'חופשי מסלול', limit: '100000000', price: '0' },
]