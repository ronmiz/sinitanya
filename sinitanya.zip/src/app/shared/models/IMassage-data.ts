export interface IMassageData {
    titleStr:string;
    bodyStr:string;
    isOverLimit:boolean;
    isOkToOverLimit:boolean;
    actionType:number;
}