
export interface IProgramData {
    id: number,
    name: string,
    limit: number,
    price: number	
  }